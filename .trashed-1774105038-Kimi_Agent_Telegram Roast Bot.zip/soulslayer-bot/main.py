"""
SoulSlayer Bot - Sarcastic Roast Bot for Telegram
A witty, clever roast bot that respects its owner
"""

import os
import asyncio
import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters
)
from groq import Groq

# ============== CONFIGURATION ==============
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

# ============== LOGGING ==============
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============== DATABASE SETUP ==============
DB_PATH = "bot_data.db"

def init_db():
    """Initialize SQLite database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Settings table for per-chat enable/disable
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            chat_id INTEGER PRIMARY KEY,
            enabled BOOLEAN DEFAULT 1,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Message log for spam filter
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS message_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            chat_id INTEGER,
            message_count INTEGER DEFAULT 1,
            last_message TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create index for faster queries
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_message_log_user_chat 
        ON message_log(user_id, chat_id)
    ''')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")

def get_db_connection():
    """Get database connection"""
    return sqlite3.connect(DB_PATH)

# ============== SPAM FILTER ==============
SPAM_THRESHOLD = 15  # messages per hour
SPAM_WINDOW = 3600   # 1 hour in seconds

def check_spam(user_id: int, chat_id: int) -> bool:
    """Check if user is spamming. Returns True if spam detected."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    now = datetime.now()
    hour_ago = now - timedelta(seconds=SPAM_WINDOW)
    
    # Get user's message count in last hour
    cursor.execute('''
        SELECT message_count, last_message FROM message_log 
        WHERE user_id = ? AND chat_id = ?
    ''', (user_id, chat_id))
    
    result = cursor.fetchone()
    
    if result:
        count, last_msg_str = result
        last_msg = datetime.fromisoformat(last_msg_str)
        
        # Reset if last message was more than an hour ago
        if last_msg < hour_ago:
            cursor.execute('''
                UPDATE message_log 
                SET message_count = 1, last_message = ? 
                WHERE user_id = ? AND chat_id = ?
            ''', (now.isoformat(), user_id, chat_id))
            conn.commit()
            conn.close()
            return False
        
        # Check threshold
        if count >= SPAM_THRESHOLD:
            conn.close()
            return True
        
        # Increment count
        cursor.execute('''
            UPDATE message_log 
            SET message_count = message_count + 1, last_message = ? 
            WHERE user_id = ? AND chat_id = ?
        ''', (now.isoformat(), user_id, chat_id))
    else:
        # First message from this user in this chat
        cursor.execute('''
            INSERT INTO message_log (user_id, chat_id, message_count, last_message)
            VALUES (?, ?, 1, ?)
        ''', (user_id, chat_id, now.isoformat()))
    
    conn.commit()
    conn.close()
    return False

def reset_spam_count(user_id: int, chat_id: int):
    """Reset spam counter for a user"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        DELETE FROM message_log WHERE user_id = ? AND chat_id = ?
    ''', (user_id, chat_id))
    conn.commit()
    conn.close()

# ============== SETTINGS MANAGEMENT ==============
def is_chat_enabled(chat_id: int) -> bool:
    """Check if bot is enabled for a chat"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT enabled FROM settings WHERE chat_id = ?', (chat_id,))
    result = cursor.fetchone()
    conn.close()
    
    if result is None:
        # Default to enabled for new chats
        set_chat_enabled(chat_id, True)
        return True
    
    return bool(result[0])

def set_chat_enabled(chat_id: int, enabled: bool):
    """Enable or disable bot for a chat"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO settings (chat_id, enabled, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(chat_id) DO UPDATE SET
        enabled = excluded.enabled,
        updated_at = excluded.updated_at
    ''', (chat_id, enabled, datetime.now().isoformat()))
    conn.commit()
    conn.close()

# ============== FALLBACK ROASTS ==============
FALLBACK_ROASTS = [
    "Arre wah, itni creativity! Matlab itna sochna padta hai na bewakoofi mein bhi unique hone ke liye. 🎭",
    "Bhai tu apni baaton se itna impress hai, ki mirror ke saamne 2 ghante lagata hoga daily. 🪞",
    "Itni confidence kahan se laate ho? Amazon pe sell hoti hai kya? Mujhe bhi chahiye thodi. 📦",
    "Tera logic sunke Einstein ne suicide note likha tha... fir socha nahi yaar, iske level pe nahi girna. 📝",
    "Tujhe dekh ke lagta hai ki Darwin ne theory galat likhi thi. Evolution kabhi reverse bhi hota hai. 🐒",
    "Bhai tu itna 'main character' hai, ki side characters bhi tujhse better acting kar lete hain. 🎬",
    "Teri baatein sunke lagta hai ki WhatsApp University se PhD ki hai. 📚",
    "Itna overconfidence? NASA wale tujhe Mars pe bhej denge, wahan bhi oxygen nahi milegi jitni tujhe chahiye. 🚀",
    "Tujhe dekh ke samajh aaya ki 'empty vessels make the most noise' kyun bola jaata hai. 🔔",
    "Bhai tu Google pe apna naam search karta hai? Itna validation chahiye life mein? 🔍",
    "Teri personality dekh ke lagta hai ki 'loading...' likha hua hai permanently. ⏳",
    "Itna attitude? Bhai tu toh iPhone user lag raha hai... par Android ka budget wala. 📱",
    "Tujhse zyada sense toh mere keyboard ka autocorrect mein hai. ⌨️",
    "Bhai tu Netflix series hai kya? Itna time waste kar raha hai sabka. 📺",
    "Teri baaton ka IQ itna low hai ki basement mein rehta hai. 🏠"
]

import random

def get_fallback_roast() -> str:
    """Get a random fallback roast"""
    return random.choice(FALLBACK_ROASTS)

# ============== GROQ API ==============
class RoastGenerator:
    def __init__(self):
        self.client = None
        if GROQ_API_KEY:
            self.client = Groq(api_key=GROQ_API_KEY)
        self.system_prompt = self._load_system_prompt()
    
    def _load_system_prompt(self) -> str:
        """Load system prompt from souls.md"""
        try:
            with open('souls.md', 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            logger.warning("souls.md not found, using default prompt")
            return """You are SoulSlayer - a witty, sarcastic AI bot. Deliver clever roasts that are funny and sharp but never genuinely harmful. Keep it under 3 sentences."""
    
    def generate_roast(self, user_message: str, username: str = "User") -> str:
        """Generate a roast using Groq API"""
        if not self.client:
            logger.warning("Groq client not initialized, using fallback")
            return get_fallback_roast()
        
        try:
            user_prompt = f"User '{username}' said: \"{user_message}\"\n\nRoast this in Hindi-English mix (Hinglish), witty and sarcastic but not abusive:"
            
            response = self.client.chat.completions.create(
                model=GROQ_MODEL,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=1.35,
                max_tokens=350,
                top_p=0.9
            )
            
            roast = response.choices[0].message.content.strip()
            
            # Safety check - if roast is too short or empty, use fallback
            if len(roast) < 10:
                return get_fallback_roast()
            
            return roast
            
        except Exception as e:
            logger.error(f"Groq API error: {e}")
            return get_fallback_roast()

# Initialize roast generator
roast_generator = RoastGenerator()

# ============== BOT HANDLERS ==============

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user_id = update.effective_user.id
    
    if user_id == OWNER_ID:
        await update.message.reply_text(
            "Haan boss, SoulSlayer ready hai! 🔥\n\n"
            "Commands:\n"
            "/enable - Bot on karo\n"
            "/disable - Bot off karo\n"
            "/myid - Apna ID check karo\n"
            "/status - Bot status check karo"
        )
    else:
        await update.message.reply_text(
            "👋 SoulSlayer here!\n\n"
            "Main ek witty roast bot hoon.\n"
            "Mujhe reply karo ya mention karo, aur main tumhe savage reply dunga! 🔥\n\n"
            "Note: Groups mein admin ko /enable karna padega."
        )

async def enable_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Enable bot for a chat - OWNER ONLY"""
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if user_id != OWNER_ID:
        await update.message.reply_text("❌ Sirf owner yeh command use kar sakta hai!")
        return
    
    set_chat_enabled(chat_id, True)
    await update.message.reply_text("✅ SoulSlayer activated! Ab main roast karunga 🔥")

async def disable_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Disable bot for a chat - OWNER ONLY"""
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if user_id != OWNER_ID:
        await update.message.reply_text("❌ Sirf owner yeh command use kar sakta hai!")
        return
    
    set_chat_enabled(chat_id, False)
    await update.message.reply_text("😴 SoulSlayer deactivated. Ab main chup rahunga.")

async def myid_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get user's Telegram ID"""
    user_id = update.effective_user.id
    username = update.effective_user.username or "No username"
    first_name = update.effective_user.first_name or "No name"
    
    await update.message.reply_text(
        f"📋 Your Info:\n"
        f"ID: `{user_id}`\n"
        f"Username: @{username}\n"
        f"Name: {first_name}",
        parse_mode='Markdown'
    )

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check bot status"""
    chat_id = update.effective_chat.id
    enabled = is_chat_enabled(chat_id)
    
    status_text = "✅ Enabled" if enabled else "❌ Disabled"
    await update.message.reply_text(f"Bot Status: {status_text}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle incoming messages"""
    if not update.message or not update.message.text:
        return
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    username = update.effective_user.username or update.effective_user.first_name or "User"
    message_text = update.message.text
    
    # ============== OWNER PROTECTION ==============
    if user_id == OWNER_ID:
        # Owner gets special response
        if not message_text.startswith('/'):
            await update.message.reply_text("Haan boss, sun raha hu 🔥 Order do")
        return
    
    # ============== CHECK IF ENABLED ==============
    if not is_chat_enabled(chat_id):
        return
    
    # ============== SPAM FILTER ==============
    if check_spam(user_id, chat_id):
        logger.info(f"Spam detected from user {user_id} in chat {chat_id}")
        return
    
    # ============== TRIGGER CONDITIONS ==============
    should_roast = False
    
    # Check if bot is mentioned
    if context.bot.username in message_text:
        should_roast = True
    
    # Check if this is a reply to bot's message
    if update.message.reply_to_message:
        if update.message.reply_to_message.from_user.id == context.bot.id:
            should_roast = True
    
    # Private chat - always respond
    if update.effective_chat.type == 'private':
        should_roast = True
    
    if not should_roast:
        return
    
    # ============== GENERATE ROAST ==============
    try:
        # Show typing indicator
        await context.bot.send_chat_action(chat_id=chat_id, action='typing')
        
        # Generate roast
        roast = roast_generator.generate_roast(message_text, username)
        
        # Send roast
        await update.message.reply_text(roast)
        
        logger.info(f"Roast sent to {username} ({user_id})")
        
    except Exception as e:
        logger.error(f"Error handling message: {e}")
        # Send fallback roast on error
        await update.message.reply_text(get_fallback_roast())

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors"""
    logger.error(f"Update {update} caused error: {context.error}")

# ============== MAIN FUNCTION ==============
def main():
    """Start the bot"""
    # Validate configuration
    if not TELEGRAM_TOKEN:
        logger.error("TELEGRAM_TOKEN not set!")
        return
    
    if OWNER_ID == 0:
        logger.warning("OWNER_ID not set! Owner protection disabled!")
    
    if not GROQ_API_KEY:
        logger.warning("GROQ_API_KEY not set! Using fallback roasts only.")
    
    # Initialize database
    init_db()
    
    # Build application
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("enable", enable_command))
    application.add_handler(CommandHandler("disable", disable_command))
    application.add_handler(CommandHandler("myid", myid_command))
    application.add_handler(CommandHandler("status", status_command))
    
    # Message handler - handle all text messages
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Error handler
    application.add_error_handler(error_handler)
    
    logger.info("SoulSlayer Bot started!")
    
    # Run the bot
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
