# 🔥 SoulSlayer Bot

A witty, sarcastic Telegram roast bot that delivers clever comebacks without genuine abuse.

## Features

- ✅ **Owner Protection** - Owner ko kabhi roast nahi karega, sirf respect
- ✅ **Smart Roasts** - Groq AI se witty, funny roasts
- ✅ **Spam Filter** - 1 hour mein 15+ messages = ignore
- ✅ **Per-Group Control** - /enable aur /disable commands
- ✅ **Fallback Roasts** - API fail ho toh local se reply
- ✅ **Anti-Jailbreak** - "be nice" try karne pe aur zor se roast

## Project Structure

```
soulslayer-bot/
├── main.py              # Main bot code
├── souls.md             # Bot personality/prompt
├── requirements.txt     # Python dependencies
├── Procfile             # Railway deploy config
├── runtime.txt          # Python version
├── .env.example         # Environment variables template
├── bot_data.db          # SQLite database (auto-created)
└── README.md            # This file
```

## Commands

| Command | Description | Who Can Use |
|---------|-------------|-------------|
| `/start` | Bot start kare | Anyone |
| `/enable` | Bot activate kare | Owner only |
| `/disable` | Bot deactivate kare | Owner only |
| `/myid` | Apna Telegram ID dekhe | Anyone |
| `/status` | Bot status check kare | Anyone |

## Setup Instructions

### Step 1: Telegram Bot Token

1. [@BotFather](https://t.me/BotFather) pe jao
2. `/newbot` command do
3. Bot ka naam do (e.g., "SoulSlayerBot")
4. Username do (e.g., "@yoursoulslayerbot")
5. **Token copy kar lo** - yeh important hai!

### Step 2: Owner ID Get Karo

1. [@userinfobot](https://t.me/userinfobot) pe jao
2. Start karo
3. Aapka ID dikh jayega (e.g., `123456789`)
4. **Yeh ID copy kar lo**

### Step 3: Groq API Key

1. [console.groq.com](https://console.groq.com/keys) pe jao
2. Sign up/login karo
3. "Create API Key" pe click karo
4. **Key copy kar lo**

### Step 4: Local Testing

```bash
# 1. Clone/download project
# 2. Install dependencies
pip install -r requirements.txt

# 3. Create .env file
cp .env.example .env

# 4. Edit .env and add your values
# TELEGRAM_TOKEN=your_token
# OWNER_ID=your_id
# GROQ_API_KEY=your_key

# 5. Run bot
python main.py
```

## Railway Pe Deploy Karna

### Step 1: GitHub Pe Push Karo

```bash
# New repository banao GitHub pe
# Phir yeh commands:
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/soulslayer-bot.git
git push -u origin main
```

### Step 2: Railway Setup

1. [railway.app](https://railway.app) pe jao
2. Sign up/login karo (GitHub se connect karo)
3. "New Project" → "Deploy from GitHub repo"
4. Apna repository select karo
5. **Important:** "Add Variables" pe click karo:

```
TELEGRAM_TOKEN = your_telegram_bot_token
OWNER_ID = your_telegram_user_id
GROQ_API_KEY = your_groq_api_key
GROQ_MODEL = llama-3.3-70b-versatile
```

6. "Deploy" pe click karo

### Step 3: Verify Deployment

1. Railway dashboard pe logs check karo
2. "SoulSlayer Bot started!" dikhe toh success hai
3. Telegram pe bot ko test karo

## How It Works

### Triggers (Kab Roast Karega)

1. **Private DM** - Direct message pe hamesha reply
2. **@Mention** - Agar bot ko mention karo
3. **Reply** - Bot ke message pe reply karo

### Owner Protection

```python
if user_id == OWNER_ID:
    # Always respectful
    return "Haan boss, sun raha hu 🔥 Order do"
```

### Spam Filter

- 1 hour = 3600 seconds window
- 15 messages = threshold
- 15+ messages = ignore for 1 hour

### Database Tables

**settings**
- `chat_id` - Group/Chat ID
- `enabled` - Bot on/off status
- `updated_at` - Last update time

**message_log**
- `user_id` - User ka ID
- `chat_id` - Chat ka ID  
- `message_count` - Kitne messages bheje
- `last_message` - Last message timestamp

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `TELEGRAM_TOKEN` | ✅ Yes | BotFather se mila token |
| `OWNER_ID` | ✅ Yes | Aapka Telegram user ID |
| `GROQ_API_KEY` | ✅ Yes | Groq console se API key |
| `GROQ_MODEL` | ❌ No | Model name (default: llama-3.3-70b-versatile) |

## Groq Models Available

- `llama-3.3-70b-versatile` (Recommended)
- `llama-3.1-8b-instant`
- `mixtral-8x7b-32768`
- `gemma-7b-it`

## Troubleshooting

### Bot Reply Nahi De Raha

1. Check logs: Railway dashboard → Logs
2. Verify TELEGRAM_TOKEN sahi hai
3. Bot ko group mein admin banao

### "Owner Only" Error

1. Apna OWNER_ID verify karo
2. `.env` ya Railway variables check karo

### API Errors

1. GROQ_API_KEY verify karo
2. API key active hai ki nahi check karo
3. Fallback roasts automatically use honge

### Database Errors

- `bot_data.db` auto-create hoti hai
- Permission issues ho toh manually create karo

## Customization

### Apne Roasts Add Karo

`souls.md` mein edit karo - yeh bot ki personality hai

### Fallback Roasts Change Karo

`main.py` mein `FALLBACK_ROASTS` list edit karo:

```python
FALLBACK_ROASTS = [
    "Tera apna roast yahan add karo...",
    "Aur bhi roasts..."
]
```

### Temperature Adjust Karo

`main.py` mein:
```python
temperature=1.35,  # Kam karo for less random, zyada karo for more creative
```

## Safety Guidelines

Yeh bot **witty roasts** deta hai, **genuine abuse nahi**:

✅ **Allowed:**
- Clever wordplay
- Sarcastic observations
- IQ jokes about behavior
- Pop culture references
- Self-deprecating humor

❌ **Not Allowed:**
- Hate speech
- Family attacks
- Body shaming
- Violent threats
- Discriminatory content

## License

MIT License - Free to use and modify!

## Credits

Made with 🔥 by a fellow developer

---

**Chal ab deploy kar aur maze le! 🚀**
